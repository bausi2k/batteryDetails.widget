batteryDetails.widget
=====================

A little widget for Übersicht to see your battey details. This widget ist based on the widget from Eric Miller (Load Average) that you may check out on [Übersicht Widgets](http://tracesof.net/uebersicht-widgets/).

__Description:__ You get 3 columns with the _battery used_, _charge percentage_ and _charge state_

__Usage:__ Just put it in your _Übersicht_ widget foler and your done.
